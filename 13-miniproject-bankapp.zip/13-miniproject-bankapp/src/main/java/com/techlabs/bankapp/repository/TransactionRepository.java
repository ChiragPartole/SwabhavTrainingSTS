package com.techlabs.bankapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.techlabs.bankapp.entity.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction, Integer>{

}
