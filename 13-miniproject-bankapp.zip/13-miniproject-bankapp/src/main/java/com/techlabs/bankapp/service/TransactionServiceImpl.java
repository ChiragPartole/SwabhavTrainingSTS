package com.techlabs.bankapp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.techlabs.bankapp.dto.PageResponse;
import com.techlabs.bankapp.dto.TransactionDto;
import com.techlabs.bankapp.entity.Account;
import com.techlabs.bankapp.entity.Transaction;
import com.techlabs.bankapp.entity.TransactionType;
import com.techlabs.bankapp.repository.AccountRepository;
import com.techlabs.bankapp.repository.TransactionRepository;

import jakarta.servlet.http.HttpSession;

@Service
public class TransactionServiceImpl implements TransactionService{

	@Autowired
	private TransactionRepository transactionRepo;
	
	@Autowired
	private AccountRepository accountRepo;
	
	@Override
	public PageResponse<Transaction> viewAllTransactions(int pageNo, int pageSize) {
	    Pageable pageable = PageRequest.of(pageNo, pageSize);
	    Page<Transaction> transactionPage = transactionRepo.findAll(pageable);
	    PageResponse<Transaction> transactionPageResponse = new PageResponse<>();
	    
	    transactionPageResponse.setContent(transactionPage.getContent());
	    transactionPageResponse.setLastPage(transactionPage.isLast());
	    transactionPageResponse.setSize(transactionPage.getSize());
	    transactionPageResponse.setTotalElements(transactionPage.getTotalElements());
	    transactionPageResponse.setTotalPages(transactionPage.getTotalPages());

	    return transactionPageResponse;
	}


	@Override
	public TransactionDto addTransaction(TransactionDto transactionDto) {
		long senderAccNo = transactionDto.getSenderAccountNumber();
		Account senderAccount = accountRepo.findByAccountNumber(senderAccNo);
		if(senderAccount ==null) {
			System.out.println("no sender account found");
			return null;
		}
		
		long receiverAccNo = transactionDto.getReceiverAccountNumber();
		Account receiverAccount = accountRepo.findByAccountNumber(receiverAccNo);
		if(receiverAccount ==null) {
			System.out.println("no receiver account found");
			return null;
		}
		
		Transaction transaction = new Transaction();
		
		if(transactionDto.getTransactionType() == TransactionType.CREDIT)
			transaction = credit(senderAccount,transactionDto);
		if(transactionDto.getTransactionType() == TransactionType.DEBIT)
			transaction = debit(senderAccount,transactionDto);
		
		 if (transaction != null) {
		        transactionRepo.save(transaction);
		        accountRepo.save(senderAccount);
		        accountRepo.save(receiverAccount);
		    }

		    return transactionDto;
		
		
	}

	private Transaction credit(Account senderAccount, TransactionDto transactionDto) {
		Transaction transaction = new Transaction();
	    
	    // Set transaction details
	    transaction.setAmount(transactionDto.getAmount());
	    transaction.setTransactionType(TransactionType.CREDIT);
	    transaction.setSenderAccount(senderAccount);

	    // Find and set the receiver account
	    long receiverAccNo = transactionDto.getReceiverAccountNumber();
	    Account receiverAccount = accountRepo.findByAccountNumber(receiverAccNo);
	    
	    if (receiverAccount == null) {
	        System.out.println("Receiver account not found");
	        return null;  // Or handle it according to your application's needs
	    }
	    transaction.setReceiverAccount(receiverAccount);

	    // Update receiver's balance
	    double existingBalance = receiverAccount.getBalance();
	    double amount = transactionDto.getAmount();
	    double newBalance = existingBalance + amount;
	    receiverAccount.setBalance(newBalance);

	    // Update sender's transactions
	    List<Transaction> senderTransactions = senderAccount.getSenderAccounts();
	    if (senderTransactions == null) {
	        senderTransactions = new ArrayList<>();
	    }
	    senderTransactions.add(transaction);
	    senderAccount.setSenderAccounts(senderTransactions);

	    // Update receiver's transactions
	    List<Transaction> receiverTransactions = receiverAccount.getReceiverAccounts();
	    if (receiverTransactions == null) {
	        receiverTransactions = new ArrayList<>();
	    }
	    receiverTransactions.add(transaction);
	    receiverAccount.setReceiverAccounts(receiverTransactions);

	    return transaction;
	}
	
	private Transaction debit(Account senderAccount, TransactionDto transactionDto) {
		Transaction transaction = new Transaction();
	    
	    // Set transaction details
	    transaction.setAmount(transactionDto.getAmount());
	    transaction.setTransactionType(TransactionType.CREDIT);
	    transaction.setSenderAccount(senderAccount);

	    // Find and set the receiver account
	    long receiverAccNo = transactionDto.getReceiverAccountNumber();
	    Account receiverAccount = accountRepo.findByAccountNumber(receiverAccNo);
	    
	    if (receiverAccount == null) {
	        System.out.println("Receiver account not found");
	        return null;  // Or handle it according to your application's needs
	    }
	    transaction.setReceiverAccount(receiverAccount);

	    // Update receiver's balance
	    double existingBalance = receiverAccount.getBalance();
	    double amount = transactionDto.getAmount();
	    double newBalance = existingBalance - amount;
	    receiverAccount.setBalance(newBalance);

	    // Update sender's transactions
	    List<Transaction> senderTransactions = senderAccount.getSenderAccounts();
	    if (senderTransactions == null) {
	        senderTransactions = new ArrayList<>();
	    }
	    senderTransactions.add(transaction);
	    senderAccount.setSenderAccounts(senderTransactions);

	    // Update receiver's transactions
	    List<Transaction> receiverTransactions = receiverAccount.getReceiverAccounts();
	    if (receiverTransactions == null) {
	        receiverTransactions = new ArrayList<>();
	    }
	    receiverTransactions.add(transaction);
	    receiverAccount.setReceiverAccounts(receiverTransactions);

	    return transaction;
	}
	
	
	
	
	
	
	
	


	@Override
	public void deleteTransaction(int transactionID) {
		transactionRepo.deleteById(transactionID);		
	}

	@Override
	public Transaction updateTransaction(TransactionDto transactionDto) {
		// TODO Auto-generated method stub
		return null;
	}










}
