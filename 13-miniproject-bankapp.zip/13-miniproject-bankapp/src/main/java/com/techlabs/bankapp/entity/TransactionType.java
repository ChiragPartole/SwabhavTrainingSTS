package com.techlabs.bankapp.entity;

public enum TransactionType {

	CREDIT,DEBIT
}
