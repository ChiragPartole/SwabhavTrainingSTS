package com.techlabs.bankapp.entity;

public enum Roles {

	ADMIN,USER
}
