package com.techlabs.bankapp.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.techlabs.bankapp.dto.AccountDto;
import com.techlabs.bankapp.dto.TransactionDto;
import com.techlabs.bankapp.service.AccountService;
import com.techlabs.bankapp.service.TransactionService;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/bankingapp")
public class UserController {

	@Autowired
	private TransactionService transactionService;
	
	@Autowired
	private AccountService accountService;
	
	@GetMapping("/users")
	public ResponseEntity<Set<AccountDto>> viewAccountDetails(HttpSession session){
		return ResponseEntity.ok(accountService.viewAccountDetails(session));
	}
	
	@PostMapping("/transactions")
	public ResponseEntity<TransactionDto> addNewTransaction(@RequestBody TransactionDto transactionDto){
		return ResponseEntity.ok(transactionService.addTransaction(transactionDto));
	}
	
	
	
	
	
	
}
