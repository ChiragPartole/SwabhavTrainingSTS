package com.techlabs.bankapp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.techlabs.bankapp.dto.CustomerDto;
import com.techlabs.bankapp.dto.PageResponse;
import com.techlabs.bankapp.dto.UserDto;
import com.techlabs.bankapp.entity.Customer;
import com.techlabs.bankapp.entity.Roles;
import com.techlabs.bankapp.entity.User;
import com.techlabs.bankapp.repository.CustomerRepository;

import jakarta.servlet.http.HttpSession;

@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	private CustomerRepository customerRepo;
	
	@Autowired
	private UserService userService;
	
	private Customer toCustomerMapper(CustomerDto customerDto) {
		Customer customer = new Customer();
		customer.setFirstName(customerDto.getFirstName());
		customer.setLastName(customerDto.getLastName());
		customer.setEmail(customerDto.getEmail());
		customer.setPassword(customerDto.getPassword());
		return customer;
	}
	
	private CustomerDto toCustomerDtoMapper(Customer customer) {
		CustomerDto customerDto = new CustomerDto();
		customerDto.setFirstName(customer.getFirstName());
		customerDto.setLastName(customer.getLastName());
		customerDto.setEmail(customer.getEmail());
		customerDto.setPassword(customer.getPassword());
		return customerDto;
	}
	
	@Override
	public PageResponse<CustomerDto> viewAllCustomers(int pageNoValue, int pageSizeValue) {
		Pageable pageable = PageRequest.of(pageNoValue, pageSizeValue);
		Page<Customer> customerPage = customerRepo.findAll(pageable);
		

		PageResponse<CustomerDto> response = new PageResponse<CustomerDto>();
		
		response.setTotalPages(customerPage.getTotalPages());
		response.setTotalElements(customerPage.getTotalElements());
		response.setSize(customerPage.getSize());
		response.setLastPage(customerPage.isLast());
		
		List<CustomerDto> customerDtoList = new ArrayList<>();
		
		customerPage.getContent().forEach((customer)->{
			customerDtoList.add(toCustomerDtoMapper(customer));
		});
		
		response.setContent(customerDtoList);
		return response;
	}

	@Override
	public CustomerDto addCustomer(CustomerDto customerDto,HttpSession session) {
		
	    Customer customer = toCustomerMapper(customerDto);
	    
	    
	    UserDto userDto = new UserDto();
	    userDto.setUserName(customerDto.getEmail());
	    userDto.setUserPassword(customerDto.getPassword());
	    userDto.setRole(Roles.USER);
	    
	    User user = userService.addUser(userDto);
	    
	    allocateUserToCustomer(user,customerDto,session);
	    
	    
	    return toCustomerDtoMapper(customer);
	}
	
	
	private void allocateUserToCustomer(User user, CustomerDto customerDto,HttpSession session) {
		Customer customer = toCustomerMapper(customerDto);
		
		customer.setUser(user);
		
		customerRepo.save(customer);
		session.setAttribute("customerID", customer.getCustomerID());
		System.out.println(session.getAttribute("customerID"));
	}

	@Override
	public Customer updateCustomer(CustomerDto customerDto) {
		// TODO Auto-generated method stub
		return null;
	}

	
	@Override
	public void deleteCustomer(int customerID) {
		customerRepo.deleteById(customerID);
	}

}
